Owner: Christopher Cervantes-Hernandez

=============
Description
=============
	This LISP program encodes and decodes an inputted sublist phrase, such as ((H E L L O)(W O R L D))
	and then returns the encrypted/decrypted messages. The encryption is a Caesar Cipher that
	shifts the letter up/down by 7 (the value 7 can thus be seen as the "key").

=============
Compiler used
=============
	CommonLisp/Clisp

	How to use: If the required file is located within the same folder you are currently in,
        	    then type the following segment within Empress without quotations:
        	    'clisp -c CervantesCipher.lsp'


=============
How to run
=============
   Because the compiled program is already included, you can the run the program by typing(in Empress):
	1.    clisp
	2.    (load "CervantesCipher.fas")
	3.    (encodeList '((P R O G R A M M I N G)(L A N G U A G E S)))
	4.    (decodeList '((I K H Z K T F F B G Z)(E T G Z N T Z X L)))


   Note: The inputted sublist phrases HAVE to be in capital letters, as the 
	 cipher isn't defined for lowercase letters.

   Alternatively, should the compiled file be missing, compile the program using clisp(as stated above),
   and run the program by typing the instructions below(without quotes):
	1.    clisp -c CervantesCipher.lsp
	2.    clisp
	3.    (load "CervantesCipher.lsp")
	4.    (encodeList '((P R O G R A M M I N G)(L A N G U A G E S)))
	5.    (decodeList '((I K H Z K T F F B G Z)(E T G Z N T Z X L)))